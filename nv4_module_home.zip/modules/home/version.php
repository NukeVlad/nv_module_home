<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VINADES.,JSC (contact@vinades.vn)
 * @copyright 2009
 * @createdate 05/07/2010 09:47
 */

if( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array(
	"name" => "NukeViet Home",
	"modfuncs" => "main",
	"is_sysmod" => 0,
	"virtual" => 0,
	"version" => "4.0.29",
	"date" => "Sat, 15 Jun 2013 00:00:00 GMT",
	"author" => "Thuc Vinh (thucvinh_arc@yahoo.com.vn)",
	"note" => "",
	"uploads_dir" => array(),
	"files_dir" => array()
);

?>